from django.db import models
from .product import Product




class ProductReview(models.Model):

	product = Product()
	product_id = models.ForeignKey(Product, on_delete=models.CASCADE)
	review = models.CharField(max_length=500)


	@staticmethod
	def getreview(product_id):
		return ProductReview.objects.filter(product_id=product_id)
		

	def save_review(self):		
		self.save()