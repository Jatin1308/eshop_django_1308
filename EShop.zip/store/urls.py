from django.urls import path
from .views import  home,login,signup, cart  # here i can use path('cart', cart.Cart.as_view(),name='cart')
from .views.login import logout
# from .view.cart import Cart      # it will lead to use path('cart', Cart.as_view(),name='cart')
from .views import checkout
from .views import orders
from .views import prod_desc
from .views import productreview

from .middlewares.auth import auth_middleware

urlpatterns = [
			path('', home.Index.as_view(), name='homepage'),
			path('products', home.Index.as_view(), name='product-page'),
			path('products/<int:product_id>',prod_desc.Product_Description.as_view(),name='product_description'),
			path('signup', signup.Signup.as_view(), name='signup'),       #signup - file nameSignup - class name is file 'signup.py'
			path('login',login.Login.as_view(), name='login'),
			path('logout',logout,name='logout'),
			path('cart',cart.Cart.as_view(), name='cart'),
			path('check-out',auth_middleware(checkout.CheckOut.as_view()),name='checkout'),
			path('orders',auth_middleware(orders.OrderView.as_view()),name='order'),
			path('review',productreview.Review.as_view(), name='review')
	]