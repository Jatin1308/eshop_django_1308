from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.customer import Customer   # .models.customer :- folder named - model and file in it named customer, this file has class Customer
from store.models.product import Product
from django.views import View
import re
from django.contrib import messages
from store.models.product_review import ProductReview



class Review(View):
	def get(self,request):
		return redirect('homepage')

	def post(self, request):
		review = request.POST.get('review')
		p_id = request.POST.get('p_id')
		messages.success(request,'Review posted publicly!!!')


		rev = ProductReview(product_id=Product(p_id),review=review)
		rev.save()
		return redirect('homepage')



