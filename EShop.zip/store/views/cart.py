from django.shortcuts import render, redirect
from store.models.customer import Customer   # .models.customer :- folder named - model and file in it named customer, this file has class Customer
from django.views import View
from store.models.product import Product
from django.http import HttpResponse
from django.contrib import messages

class Cart(View):
	def get(self, request):    # -----------------------------------  these are the inbuilt methods for handling get or post request
		# ids = list(request.session.get('cart').keys())
		if request.session.get('cart'):
			ids = list(request.session.get('cart').keys())
			products = Product.get_products_by_id(ids)
			return render(request,'cart.html',{'products':products})
		else:
			messages.warning(request,'Please add products into the cart!')
			return redirect('homepage')
	