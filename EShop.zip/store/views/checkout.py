from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from store.models.orders import Order
from django.views import View



class CheckOut(View):
	def post(self, request):
		address = request.POST.get('address')
		phone = request.POST.get('phone')
		customer = request.session['customer_id']
		cart = request.session.get('cart')
		products = Product.get_products_by_id(list(cart.keys()))

		for product in products:
			order = Order(customer=Customer(id=customer),product=product, price=product.price,quantity = cart.get(str(product.id)), address=address, phone=phone)
			order.save()

		request.session['cart'] = {}
		# messages.info(request,'Welcome again, Your order has been placed')
		return redirect('cart')