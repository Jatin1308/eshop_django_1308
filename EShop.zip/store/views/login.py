from django.shortcuts import render, redirect, HttpResponseRedirect
from store.models.customer import Customer   # .models.customer :- folder named - model and file in it named customer, this file has class Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from django.contrib import messages

class Login(View):
	return_url = None

	def get(self, request):    # -----------------------------------  these are the inbuilt methods for handling get or post request
		Login.return_url = request.GET.get('return_url')
		print("return_url is: ",Login.return_url)
		return render(request,'login.html')



	def post(self,request):
		email = request.POST.get('email')
		password = request.POST.get('password')
		customer = Customer.get_customer_by_email(email)
		error_message = None
		if customer:
			flag = check_password(password,customer.password)
			if flag:
				request.session['customer_id'] = customer.id
				
				if Login.return_url:
					return HttpResponseRedirect(Login.return_url)
				else:
					Login.return_url = None
					messages.success(request,'Successfully logged in!')
					return redirect('homepage')
			else:
				error_message = 'Email or Password invalid'
		else:
			error_message = 'Email or Password invalid'

		return render(request, 'login.html',{'error':error_message})





def logout(request):
	request.session.clear()
	messages.info(request,"Login again! or Explore our brand new Products.")
	return redirect('login')