from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from store.models.orders import Order
from store.models.product_review import ProductReview
from django.views import View

from store.middlewares.auth import auth_middleware


import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
import joblib
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB


class Product_Description(View):



	def get(self,request,product_id):
		product = Product.product_desc(product_id)
		reviews = ProductReview.getreview(product_id)
		r = []
		for i in range(len(reviews)):
			r.append(reviews[i].review)





		# ml model - naive bayes

		data = pd.read_csv('/home/jatin/Desktop/final_project/EShop/store/views/google_play_store_apps_reviews_training.csv')
		data = data.drop('package_name', axis=1)
		# Convert text to lowercase
		data['review'] = data['review'].str.strip().str.lower()
		x = data['review']
		y = data['polarity']
		x, x_test, y, y_test = train_test_split(x,y, stratify=y, test_size=0.25, random_state=42)
		# Vectorize text reviews to numbers
		vec = CountVectorizer(stop_words='english')
		x = vec.fit_transform(x).toarray()
		x_test = vec.transform(x_test).toarray()
		model = MultinomialNB()
		model.fit(x, y)

		d = {}
		pos = 0
		neg = 0
		for x in r:
			m = model.predict(vec.transform([x]))
			if m[0] == 1:
				d[x] = "Positive Comment"
				pos += 1
			elif m[0] == 0:
				d[x] = "Negative Comment"
				neg+=1

		if len(r) != 0: 
			pos_percentage = (pos/(pos+neg))*100
			neg_percentage = 100 - pos_percentage
			pos_percentage = "{:.2f}".format(pos_percentage)
			neg_percentage = "{:.2f}".format(neg_percentage)
		else:
			pos_percentage = 0
			neg_percentage = 0
		return render(request,'prod_desc.html',{'product':product[0],'rev_sent':d.items(),'p_per':pos_percentage,'n_per':neg_percentage})



